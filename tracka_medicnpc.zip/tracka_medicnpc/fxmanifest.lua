fx_version 'cerulean'
game 'gta5'
author 'Tracka'
description 'medic NPC'

server_scripts {
    "server/*"
}

client_scripts {
    "client/*"
}

shared_scripts {
    "configs/*",
    "shared/*"
}