RegisterNetEvent("esx:getplayerLoaded")
AddEventHandler("esx:getplayerLoaded", function(response)
    Heap.ESX.PlayerData = response
end)

RegisterNetEvent("tracka_medicnpc:eventHandler")
AddEventHandler("tracka_medicnpc:eventHandler", function(event, eventData)
    Trace(event, json.encode(eventData))

    if event == ""MEDIC_UNAVAILABLE"" then 
        Heap.Medics[eventData.Medic] = eventData = Bool

        local ped = GetPed(eventData.Medic)

        if ped then 
            SetEntityVisible(ped.Handle, not eventData.Bool)
        end
    elseif event == "SYNC_ANIMATION" then 
        if not NetworkDoesNetworkIdExist(eventData.ped) then 
            return 
        end 

        local pedHandle = NetToPed(eventData.ped)

        if DoesEntityExist(pedHandle) then 
            PlayAnimation(pedHandle, "anim@heists@box_carry@", "idle",{
                flag = 49

            })
        end
    end
end)

AddEventHandler("onResourceStop", function(resource)
    if resource == GetCurrentResourceName() then
        for _, pedData in pairs(Heap.Peds) do
            if DoesEntityExist(pedData.Handle) then
                DeleteEntity(pedData.Handle)
            end
        end
    end
end)