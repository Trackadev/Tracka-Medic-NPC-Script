Heap = {
    Medics = {}
}

TriggerEvent(esx:getSharedObject, function(library)
    Heap.ESX = library
end)

RegisterNetEvent("tracka_medicnpc:globalEvent")
AddEventHandler("tracka_medicnpc:globalEvent", function(options)
    TriggerClientEvent("tracka_medicnpc:eventHandler", -1, options.event or "none", options.data or nil)
end)


RegisterNetEvent("tracka_medicnpc:removeMoney")
AddEventHandler("tracka_medicnpc:removeMoney", function(medicIndex)
    local character = Heap.ESX.GetPlayerFromId(source)

    if not character then return end

    local medic = Medics[medicIndex]

    if not medic then return end
    if not medic.Price then medic.Price = 100 end

    character.removeMoney(medic.Price)
end)